//
// Created by shkstart on 2023/9/28.
//

//#include <iostream>
//
//void f2(int &x) {
//    x = x + 1;
//}
//
//int main() {
//    int a = 1;
//    f2(a);
//    std::cout << "a = " << a << std::endl; // a = 2
//
//    return 0;
//}