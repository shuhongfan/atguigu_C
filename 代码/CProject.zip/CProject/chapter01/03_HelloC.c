//
// Created by shkstart on 2023/8/23.
//

#include <stdio.h>
#include "stdlib.h"

/*
 * main()是程序的入口，格式是固定的。
 *  int:表示函数的返回值类型
 *  return 0: 程序终止；程序执行成功
 * */
int main() {
    //内部的都是属于main()的函数体
    int i = 10;  //定义一个变量
    printf("Hello, World!\n");  // \n:表示换行操作
    printf("2 + 3 = 5");
    return 0;
}

