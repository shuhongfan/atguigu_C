//
// Created by shkstart on 2023/8/23.
//

#include <stdio.h>

int main() {
    printf("Hello, World!\n");
    return 0;
}
